package net.server.InfoViescCat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoViescCatApplicationTests {

	@Test
	void contextLoads() {
	}

}
